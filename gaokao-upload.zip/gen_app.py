content = r'''import streamlit as st
import pandas as pd
from gaokao.engine import ZhangXuefengEngine
from gaokao.models import StudentInput, FamilyCondition, SubjectType
from gaokao.data.majors import MAJORS
from gaokao.data.universities import JIANGXI_DATA
from gaokao.data.zhangxuefeng import ZHANG_XUEFENG_FRAMEWORK, ZHANG_XUEFENG_MAJOR_CATEGORIES
from gaokao.data.personality import HOLLAND_CODES, MBTI_MAJOR_MAP, calculate_holland, recommend_majors_by_holland, PERSONALITY_QUESTIONS
from gaokao.data.universities_ext import get_extra_universities
from gaokao.data.major_details_ext import get_major_deep_analysis_ext
from gaokao.data.employment_deep_ext import get_major_employment_deep_ext
from gaokao.data.major_city_ext import get_major_city_match_ext
from gaokao.data.decision_ext import get_major_score_card_ext, get_common_mistakes_ext
from gaokao.data.school_major_match_ext import get_school_major_match_ext
from gaokao.data.rankings_ext import get_ranking_ext
from gaokao.data.school_living import get_school_living, FRESHMAN_TIPS
from gaokao.data.career_path import get_career_path
from gaokao.data.financial_aid import SCHOLARSHIP_TYPES, FINANCIAL_PLANNING
from gaokao.data.quickref import get_major_golden_rules

st.set_page_config(page_title="\u9ad8\u8003\u5fd7\u613f\u7b56\u7565\u5e08", page_icon="\U0001f393", layout="wide")

# ========== CUSTOM CSS ==========
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@300;400;500;700;900&display=swap');

* { font-family: 'Noto Sans SC', sans-serif; }

.stApp {
    background: linear-gradient(135deg, #f0f4ff 0%, #e8edf5 100%);
}

[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
    border-right: none;
}

[data-testid="stSidebar"] .stTitle, 
[data-testid="stSidebar"] .stMarkdown {
    color: white !important;
}

[data-testid="stSidebar"] .stRadio > div {
    gap: 4px;
}

[data-testid="stSidebar"] .stRadio label {
    background: rgba(255,255,255,0.08);
    color: rgba(255,255,255,0.8);
    padding: 12px 16px;
    border-radius: 10px;
    border: 1px solid rgba(255,255,255,0.05);
    transition: all 0.3s ease;
    font-weight: 400;
    cursor: pointer;
}

[data-testid="stSidebar"] .stRadio label:hover {
    background: rgba(255,255,255,0.15);
    color: white;
    border-color: rgba(255,255,255,0.2);
    transform: translateX(4px);
}

[data-testid="stSidebar"] .stRadio label[data-selected="true"] {
    background: linear-gradient(135deg, #e8b840 0%, #f5a623 100%) !important;
    color: #1a1a2e !important;
    border-color: #f5a623 !important;
    font-weight: 600;
    box-shadow: 0 4px 15px rgba(245, 166, 35, 0.3);
}

[data-testid="stSidebar"] .stRadio div[role="radiogroup"] > label:first-child {
    margin-top: 8px;
}

h1, h2, h3 {
    font-weight: 700 !important;
    letter-spacing: -0.02em;
}

.stButton > button {
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
    color: white !important;
    border: none;
    padding: 12px 32px;
    border-radius: 12px;
    font-weight: 600;
    font-size: 16px;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(26, 26, 46, 0.2);
    letter-spacing: 0.5px;
}

.stButton > button:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(26, 26, 46, 0.3);
    background: linear-gradient(135deg, #16213e 0%, #0f3460 100%);
}

.stButton > button:active {
    transform: translateY(0);
}

div[data-testid="stExpander"] {
    background: white;
    border-radius: 14px;
    border: 1px solid rgba(0,0,0,0.06);
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
    margin-bottom: 12px;
    overflow: hidden;
}

div[data-testid="stExpander"] > div:first-child {
    background: white;
    border-radius: 14px;
    padding: 4px 16px;
}

div[data-testid="stExpander"] > div:first-child:hover {
    background: #f8f9fc;
}

[data-testid="stTab"] {
    background: white;
    border-radius: 12px 12px 0 0;
    padding: 8px 24px;
    font-weight: 500;
}

[data-testid="stTab"][aria-selected="true"] {
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
    color: white !important;
}

[data-testid="stDataFrame"] {
    background: white;
    border-radius: 14px;
    border: 1px solid rgba(0,0,0,0.06);
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
    overflow: hidden;
}

[data-testid="stDataFrame"] thead tr th {
    background: #f8f9fc;
    font-weight: 600;
    color: #1a1a2e;
    border-bottom: 2px solid #e8b840;
}

[data-testid="stMetric"] {
    background: white;
    border-radius: 14px;
    padding: 16px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.04);
    border: 1px solid rgba(0,0,0,0.06);
}

[data-testid="stMetric"] label {
    color: #666;
    font-weight: 500;
    font-size: 13px;
}

[data-testid="stMetric"] [data-testid="stMetricValue"] {
    font-weight: 700;
    color: #1a1a2e;
}

[data-testid="stSuccess"] {
    background: linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%);
    border: 1px solid #a5d6a7;
    border-left: 4px solid #4caf50;
    border-radius: 12px;
    padding: 16px 20px;
    color: #1b5e20;
}

[data-testid="stInfo"] {
    background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
    border: 1px solid #90caf9;
    border-left: 4px solid #2196f3;
    border-radius: 12px;
}

[data-testid="stWarning"] {
    background: linear-gradient(135deg, #fff8e1 0%, #ffecb3 100%);
    border: 1px solid #ffe082;
    border-left: 4px solid #ffc107;
    border-radius: 12px;
}

[data-testid="stError"] {
    background: linear-gradient(135deg, #ffebee 0%, #ffcdd2 100%);
    border: 1px solid #ef9a9a;
    border-left: 4px solid #f44336;
    border-radius: 12px;
}

.stNumberInput input, .stSelectbox select, .stTextInput input {
    border-radius: 10px !important;
    border: 2px solid #e0e0e0 !important;
    padding: 8px 12px !important;
    transition: all 0.3s ease !important;
}

.stNumberInput input:focus, .stSelectbox select:focus, .stTextInput input:focus {
    border-color: #1a1a2e !important;
    box-shadow: 0 0 0 3px rgba(26, 26, 46, 0.1) !important;
}

.stSelectbox > div > div {
    border-radius: 10px !important;
    border: 2px solid #e0e0e0 !important;
}

.stSelectbox > div > div:focus {
    border-color: #1a1a2e !important;
}

.stRadio > div {
    flex-direction: row !important;
    gap: 8px;
}

.stRadio label {
    background: white;
    border: 2px solid #e0e0e0;
    padding: 6px 18px;
    border-radius: 20px;
    font-size: 14px;
    cursor: pointer;
    transition: all 0.3s ease;
}

.stRadio label:hover {
    border-color: #1a1a2e;
    background: #f0f4ff;
}

.stRadio label[data-selected="true"] {
    background: #1a1a2e !important;
    color: white !important;
    border-color: #1a1a2e !important;
}

.st-emotion-cache-1kyxreq {
    justify-content: center;
}

.card {
    background: white;
    border-radius: 16px;
    padding: 24px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.06);
    border: 1px solid rgba(0,0,0,0.04);
    margin-bottom: 16px;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.card:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 30px rgba(0,0,0,0.1);
}

.card-title {
    font-size: 18px;
    font-weight: 700;
    color: #1a1a2e;
    margin-bottom: 8px;
}

.card-subtitle {
    font-size: 13px;
    color: #888;
    margin-bottom: 12px;
}

.divider {
    height: 2px;
    background: linear-gradient(90deg, #e8b840 0%, transparent 100%);
    margin: 24px 0;
    border: none;
}

.sidebar-header {
    padding: 24px 16px 16px;
    text-align: center;
    border-bottom: 1px solid rgba(255,255,255,0.1);
    margin-bottom: 16px;
}

.sidebar-header h2 {
    color: white;
    font-size: 22px;
    font-weight: 900;
    margin: 0;
    letter-spacing: 1px;
}

.sidebar-header p {
    color: rgba(255,255,255,0.5);
    font-size: 12px;
    margin: 4px 0 0;
}

.gold-badge {
    display: inline-block;
    background: linear-gradient(135deg, #e8b840 0%, #f5a623 100%);
    color: #1a1a2e;
    padding: 2px 10px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 700;
}

.tag {
    display: inline-block;
    background: #f0f4ff;
    color: #1a1a2e;
    padding: 2px 10px;
    border-radius: 6px;
    font-size: 12px;
    margin: 2px;
}

.score-bar {
    height: 6px;
    border-radius: 3px;
    background: #e0e0e0;
    overflow: hidden;
    margin: 4px 0;
}

.score-bar-fill {
    height: 100%;
    border-radius: 3px;
    background: linear-gradient(90deg, #4caf50, #8bc34a);
    transition: width 0.5s ease;
}

@keyframes fadeInUp {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}

.animate-in {
    animation: fadeInUp 0.5s ease forwards;
}

.footer {
    text-align: center;
    color: #999;
    font-size: 12px;
    padding: 32px 0 16px;
    border-top: 1px solid #eee;
    margin-top: 48px;
}
</style>
""", unsafe_allow_html=True)

# ========== SIDEBAR ==========
st.sidebar.markdown("""
<div class="sidebar-header">
    <h2>\U0001f393 \u9ad8\u8003\u5fd7\u613f\u7b56\u7565\u5e08</h2>
    <p>\u5f20\u96ea\u5cf0\u77e5\u8bc6\u6846\u67b6 \u00b7 \u6570\u636e\u9a71\u52a8\u63a8\u8350</p>
</div>
""", unsafe_allow_html=True)

PROVINCES = ["\u5317\u4eac","\u5929\u6d25","\u6cb3\u5317","\u5c71\u897f","\u5185\u8499\u53e4","\u8fbd\u5b81","\u5409\u6797","\u9ed1\u9f99\u6c5f","\u4e0a\u6d77","\u6c5f\u82cf","\u6d59\u6c5f","\u5b89\u5fbd","\u798f\u5efa","\u6c5f\u897f","\u5c71\u4e1c","\u6cb3\u5357","\u6e56\u5317","\u6e56\u5357","\u5e7f\u4e1c","\u5e7f\u897f","\u6d77\u5357","\u91cd\u5e86","\u56db\u5ddd","\u8d35\u5dde","\u4e91\u5357","\u897f\u85cf","\u9655\u897f","\u7518\u8083","\u9752\u6d77","\u5b81\u590f","\u65b0\u7586"]

page = st.sidebar.radio("", ["\U0001f3af \u5fd7\u613f\u63a8\u8350","\U0001f9e0 \u6027\u683c\u6d4b\u8bd5","\U0001f3eb \u9662\u6821\u67e5\u8be2","\U0001f4da \u4e13\u4e1a\u67e5\u8be2","\U0001f4ca \u6570\u636e\u770b\u677f"])
page_key = page.split(" ")[1] if " " in page else page

def get_all_schools():
    schools = {}
    for u in JIANGXI_DATA:
        name = u.get("name","")
        if name:
            schools[name] = {"name": name, "level": u.get("level",""), "city": u.get("city",""), "type": u.get("type",""), "nature": u.get("nature",""), "scores": u.get("scores",{}), "strong_majors": u.get("strong_majors",[])}
    for u in get_extra_universities():
        name = u.get("name","")
        if name and name not in schools:
            schools[name] = {"name": name, "level": u.get("level",""), "city": u.get("city",""), "type": u.get("type",""), "scores": u.get("scores",{})}
    return schools

ALL_SCHOOLS = get_all_schools()

def get_all_major_names():
    return sorted([m["name"] for m in MAJORS])

ALL_MAJOR_NAMES = get_all_major_names()

def make_tags(items):
    return "".join(f'<span class="tag">{i.strip()}</span>' for i in items if i.strip())

def get_major_info_by_name(name):
    for m in MAJORS:
        if m["name"] == name:
            return m
    return {}

def format_score_str(scores):
    if not scores: return ""
    parts = []
    for y in sorted(scores.keys()):
        s = scores[y]
        v = s.get("min") if isinstance(s, dict) else s
        if v: parts.append(f"{y}:{v}\u5206")
    return "\u3001".join(parts)

def score_to_color(v):
    if v >= 80: return "#4caf50"
    if v >= 60: return "#8bc34a"
    if v >= 40: return "#ffc107"
    if v >= 20: return "#ff9800"
    return "#f44336"

# ========== PAGE: \u5fd7\u613f\u63a8\u8350 ==========
if page_key == "\u5fd7\u613f\u63a8\u8350":
    st.markdown("<h1 style='font-size:32px;margin-bottom:4px'>\U0001f3af \u5fd7\u613f\u63a8\u8350</h1>", unsafe_allow_html=True)
    st.markdown("<p style='color:#888;margin-top:0;font-size:15px'>\u8f93\u5165\u4f60\u7684\u9ad8\u8003\u4fe1\u606f\uff0c\u7cfb\u7edf\u5c06\u57fa\u4e8e\u5f20\u96ea\u5cf0\u4e94\u5c42\u7b5b\u9009\u6846\u67b6\u4e3a\u4f60\u63a8\u8350\u5fd7\u613f</p>", unsafe_allow_html=True)

    with st.expander("\U0001f4d6 \u5f20\u96ea\u5cf0\u4e94\u5c42\u7b5b\u9009\u6846\u67b6", expanded=False):
        for level_name, content in ZHANG_XUEFENG_FRAMEWORK.items():
            st.markdown(f"**{level_name}**")
            st.write(content)

    st.markdown('<div class="card">', unsafe_allow_html=True)
    st.markdown('<div class="card-title">\U0001f9fe \u8f93\u5165\u4fe1\u606f</div>', unsafe_allow_html=True)
    col1, col2 = st.columns(2)
    with col1:
        score = st.number_input("\U0001f4ca \u9ad8\u8003\u5206\u6570", min_value=0, max_value=750, value=500, step=1)
        rank = st.number_input("\U0001f4c8 \u5168\u7701\u6392\u540d\uff08\u4f4d\u6b21\uff09", min_value=1, max_value=1000000, value=50000, step=100)
    with col2:
        province = st.selectbox("\U0001f30d \u7701\u4efd", PROVINCES, index=12)
        subject = st.selectbox("\U0001f4d6 \u6587\u7406\u79d1", ["\u7406\u79d1","\u6587\u79d1","\u65b0\u9ad8\u8003"])
        family = st.selectbox("\U0001f3e0 \u5bb6\u5ead\u6761\u4ef6", ["\u666e\u901a","\u6709\u77ff","\u56f0\u96be"])
    st.markdown("</div>", unsafe_allow_html=True)

    if st.button("\U0001f680 \u5f00\u59cb\u5206\u6790", type="primary", use_container_width=True):
        subject_map = {"\u7406\u79d1": SubjectType.SCIENCE, "\u6587\u79d1": SubjectType.LIBERAL_ARTS, "\u65b0\u9ad8\u8003": SubjectType.NEW_GAOKAO}
        family_map = {"\u6709\u77ff": FamilyCondition.RICH, "\u666e\u901a": FamilyCondition.NORMAL, "\u56f0\u96be": FamilyCondition.POOR}
        engine = ZhangXuefengEngine()
        student = StudentInput(score=score, province=province, subject=subject_map[subject], rank=rank, family=family_map[family])
        with st.spinner("\u6b63\u5728\u5206\u6790..."):
            result = engine.analyze(student)
        summary = result.summary or f"\u4f60\u7684\u5206\u6570\u662f{score}\u5206\uff0c\u5efa\u8bae\u6839\u636e\u4f4d\u6b21\u5408\u7406\u586b\u62a5\u3002"
        st.success(summary)

        tab1, tab2, tab3, tab4 = st.tabi(["\U0001f3eb \u5b66\u6821\u63a8\u8350", "\U0001f4da \u4e13\u4e1a\u63a8\u8350", "\U0001f3d8\ufe0f \u57ce\u5e02\u63a8\u8350", "\U0001f50d \u8be6\u7ec6\u5206\u6790"])
        with tab1:
            if result.universities:
                data = []
                for u in result.universities:
                    school = ALL_SCHOOLS.get(u.name, {})
                    ranking = get_ranking_ext(u.name)
                    living = get_school_living(u.name)
                    rank_val = ranking.get("\u8f6f\u79d1\u6392\u540d","") if ranking else ""
                    dorm = (living.get("\u5bbf\u820d\u6761\u4ef6","") or "")[:12] if living else ""
                    data.append({"\u5b66\u6821": u.name, "\u6279\u6b21": u.tier, "\u5c42\u6b21": school.get("level",""), "\u5206\u6570": u.score_range, "\u6392\u540d": rank_val, "\u5bbf\u820d": dorm})
                st.dataframe(pd.DataFrame(data), use_container_width=True, hide_index=True)
            else:
                st.info("\u6682\u65e0\u5b66\u6821\u63a8\u8350\u6570\u636e")

        with tab2:
            if result.majors:
                for m in result.majors[:8]:
                    deep = get_major_deep_analysis_ext(m.name)
                    card = get_major_score_card_ext(m.name)
                    grade = card.get("\u7b49\u7ea7","") if card else ""
                    with st.expander(f"**{m.name}** \u2003\u5c31\u4e1a\u7387 {m.employment_rate}% \u2003\u85aa\u8d44 {m.salary_median}\u5143/\u6708 \u2003<span class='gold-badge'>{grade}</span>" if grade else f"**{m.name}** \u2003\u5c31\u4e1a\u7387 {m.employment_rate}% \u2003\u85aa\u8d44 {m.salary_median}\u5143/\u6708"):
                        ca, cb = st.columns(2)
                        with ca:
                            st.markdown(f'<div style="margin-bottom:4px"><span style="color:#888;font-size:13px">\u5c31\u4e1a\u7387</span> <strong>{m.employment_rate}%</strong></div>', unsafe_allow_html=True)
                            st.markdown(f'<div style="margin-bottom:4px"><span style="color:#888;font-size:13px">\u85aa\u8d44\u4e2d\u4f4d\u6570</span> <strong>{m.salary_median}\u5143/\u6708</strong></div>', unsafe_allow_html=True)
                            if m.jobs: st.markdown(f'<div><span style="color:#888;font-size:13px">\u5c97\u4f4d</span> {m.jobs}</div>', unsafe_allow_html=True)
                        with cb:
                            if m.warning: st.warning(m.warning)
                            if deep:
                                sal = deep.get("\u85aa\u8d44\u6210\u957f",{})
                                if sal:
                                    parts = [f"{k}:{v}\u5143" for k,v in sal.items()]
                                    st.markdown(f'<div style="margin-bottom:4px"><span style="color:#888;font-size:13px">\u85aa\u8d44\u6210\u957f</span><br>{(" " + chr(0x2192) + " ").join(parts)}</div>', unsafe_allow_html=True)
                                st.markdown(f'<div style="margin-bottom:4px"><span style="color:#888;font-size:13px">\u664b\u5347\u8def\u5f84</span><br>{deep.get("\u664b\u5347\u8def\u5f84","")}</div>', unsafe_allow_html=True)
                                st.markdown(f'<div><span style="color:#888;font-size:13px">\u5de5\u4f5c\u5f3a\u5ea6</span> {deep.get("\u5de5\u4f5c\u5f3a\u5ea6","")} \u2003<span style="color:#888;font-size:13px">35\u5c81\u5371\u673a</span> {deep.get("35\u5c81\u5371\u673a","")}</div>', unsafe_allow_html=True)
            else:
                st.info("\u6682\u65e0\u4e13\u4e1a\u63a8\u8350\u6570\u636e")

        with tab3:
            if result.cities:
                for c in result.cities:
                    st.markdown(f'<div class="card"><strong>{c.city}</strong><br><span style="color:#666">{c.reason}</span></div>', unsafe_allow_html=True)
            else:
                st.info("\u6682\u65e0\u57ce\u5e02\u63a8\u8350\u6570\u636e")

        with tab4:
            col1, col2 = st.columns(2)
            with col1:
                st.markdown('<div class="card-title">\u26a0\ufe0f \u907f\u5751\u63d0\u793a</div>', unsafe_allow_html=True)
                if result.warnings:
                    for w in result.warnings: st.warning(w)
                else: st.info("\u6682\u65e0\u7279\u522b\u8b66\u544a")
                st.markdown('<div class="card-title" style="margin-top:16px">\U0001f4c8 \u5f55\u53d6\u8d8b\u52bf</div>', unsafe_allow_html=True)
                from gaokao.data.provinces import get_province_batch_lines
                lines = get_province_batch_lines("\u6c5f\u897f")
                if lines:
                    for year, batches in lines.items():
                        st.markdown(f'<div style="background:#f8f9fc;padding:8px 12px;border-radius:8px;margin-bottom:4px"><strong>{year}\u5e74</strong> \u4e00\u672c{batches.get("\u4e00\u672c","?")} / \u4e8c\u672c{batches.get("\u4e8c\u672c","?")} / \u4e13\u79d1{batches.get("\u4e13\u79d1","?")}</div>', unsafe_allow_html=True)
            with col2:
                st.markdown('<div class="card-title">\u26a0\ufe0f \u5e38\u89c1\u9677\u9631</div>', unsafe_allow_html=True)
                mistakes = get_common_mistakes_ext()
                if mistakes:
                    for key, val in list(mistakes.items())[:5]:
                        st.warning(f"{key}\uff1a{val.get('\u6b63\u786e\u505a\u6cd5','')}")
                st.markdown('<div class="card-title" style="margin-top:16px">\U0001f4a1 \u5f20\u96ea\u5cf0\u9ec4\u91d1\u6cd5\u5219</div>', unsafe_allow_html=True)
                for rule in list(get_major_golden_rules().values())[:5]:
                    st.info(rule)

    st.markdown('<hr class="divider">', unsafe_allow_html=True)
    ca, cb, cc = st.columns(3)
    with ca: st.metric("\U0001f3eb \u9662\u6821\u5e93", f"{len(ALL_SCHOOLS)}+", help="\u9ad8\u8003\u5fd7\u613f\u7b56\u7565\u5e08\u5e93")
    with cb: st.metric("\U0001f4da \u4e13\u4e1a\u5e93", f"{len(ALL_MAJOR_NAMES)}+")
    with cc: st.metric("\U0001f3d8\ufe0f \u57ce\u5e02\u5e93", "50+")

# ========== PAGE: \u6027\u683c\u6d4b\u8bd5 ==========
elif page_key == "\u6027\u683c\u6d4b\u8bd5":
    st.markdown("<h1>\U0001f9e0 \u6027\u683c\u6d4b\u8bd5</h1>", unsafe_allow_html=True)
    st.markdown("<p style='color:#888;font-size:15px'>\u56de\u7b5412\u4e2a\u7b80\u5355\u95ee\u9898\uff0c\u627e\u5230\u6700\u9002\u5408\u4f60\u6027\u683c\u7684\u4e13\u4e1a</p>", unsafe_allow_html=True)

    if "holland_answers" not in st.session_state:
        st.session_state.holland_answers = [0] * 12

    st.markdown('<div class="card">', unsafe_allow_html=True)
    st.markdown('<div class="card-title">\u8bf7\u56de\u7b54\u4ee5\u4e0b\u95ee\u9898</div>', unsafe_allow_html=True)
    answered = sum(st.session_state.holland_answers) if sum(st.session_state.holland_answers) else 0
    st.progress(answered / 12 if answered > 0 else 0.01, text=f"\u5df2\u56de\u7b54 {answered}/12")
    for i, q in enumerate(PERSONALITY_QUESTIONS):
        ans = st.radio(f"{i+1}. {q['question']}", ["\u5426","\u662f"], index=st.session_state.holland_answers[i], key=f"h_{i}", horizontal=True)
        st.session_state.holland_answers[i] = 1 if ans == "\u662f" else 0
    st.markdown("</div>", unsafe_allow_html=True)

    if st.button("\U0001f50d \u67e5\u770b\u6211\u7684\u6027\u683c\u5339\u914d\u4e13\u4e1a", type="primary", use_container_width=True):
        scores = calculate_holland(st.session_state.holland_answers)
        top_type = max(scores, key=scores.get)
        st.success(f"\u4f60\u7684\u4e3b\u5bfc\u6027\u683c\u7c7b\u578b\uff1a**{HOLLAND_CODES[top_type]['name_cn']}** \u2003\u7279\u5f81\uff1a{'\u3001'.join(HOLLAND_CODES[top_type]['traits'])}")
        st.markdown('<div class="card"><div class="card-title">\u5404\u7ef4\u5ea6\u5f97\u5206</div>', unsafe_allow_html=True)
        cols = st.columns(6)
        for i, (code, info) in enumerate(HOLLAND_CODES.items()):
            with cols[i]:
                val = scores[code]
                st.markdown(f'<div style="text-align:center;padding:12px;background:#f8f9fc;border-radius:12px"><div style="font-size:28px;font-weight:900;color:{score_to_color(val*20)}">{val}</div><div style="font-size:12px;color:#888">{info["name_cn"]}</div></div>', unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)
        st.markdown('<div class="card"><div class="card-title">\U0001f4a1 \u63a8\u8350\u4e13\u4e1a</div>', unsafe_allow_html=True)
        majors = recommend_majors_by_holland(scores, top_n=10)
        if majors:
            for major, match_score in majors:
                card = get_major_score_card_ext(major)
                grade = card.get("\u7b49\u7ea7","?") if card else "?"
                total = card.get("\u603b\u5206","?") if card else "?"
                st.markdown(f'<div style="display:flex;justify-content:space-between;align-items:center;padding:8px 12px;background:#f8f9fc;border-radius:8px;margin-bottom:4px"><span><strong>{major}</strong></span><span><span class="gold-badge">{grade}</span> \u2003{match_score}/6 \u2003{total}/100</span></div>', unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)

        st.markdown('<div class="card"><div class="card-title">MBTI \u53c2\u8003</div>', unsafe_allow_html=True)
        mbti_type = st.selectbox("\u5982\u679c\u77e5\u9053\u4f60\u7684 MBTI \u7c7b\u578b\uff0c\u5728\u8fd9\u91cc\u9009\u62e9\u67e5\u770b\u63a8\u8350\uff1a", list(MBTI_MAJOR_MAP.keys()))
        if mbti_type:
            mbti_info = MBTI_MAJOR_MAP[mbti_type]
            st.markdown(f'<span style="color:#888">{mbti_info["description"]}</span>', unsafe_allow_html=True)
            st.markdown(f'\u63a8\u8350\u4e13\u4e1a\uff1a{" \u3001 ".join(mbti_info["\u63a8\u8350\u4e13\u4e1a"])}', unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)

# ========== PAGE: \u9662\u6821\u67e5\u8be2 ==========
elif page_key == "\u9662\u6821\u67e5\u8be2":
    st.markdown("<h1>\U0001f3eb \u9662\u6821\u67e5\u8be2</h1>", unsafe_allow_html=True)
    st.markdown('<div class="card">', unsafe_allow_html=True)
    col1, col2, col3 = st.columns([2,1,1])
    with col1: search = st.text_input("\U0001f50d \u641c\u7d22\u5b66\u6821", placeholder="\u8f93\u5165\u5b66\u6821\u540d\u79f0\u8fdb\u884c\u6a21\u7cca\u641c\u7d22")
    with col2: level_filter = st.selectbox("\U0001f4c4 \u5c42\u6b21", ["\u5168\u90e8","985","211","\u53cc\u4e00\u6d41","\u672c\u79d1","\u6c11\u529e","\u4e13\u79d1"])
    with col3: province_filter = st.selectbox("\U0001f30d \u7701\u4efd", ["\u5168\u90e8"] + PROVINCES)
    st.markdown("</div>", unsafe_allow_html=True)

    filtered = {}
    for name, school in ALL_SCHOOLS.items():
        if search and search.lower() not in name.lower(): continue
        lv = school.get("level","")
        if level_filter == "985" and "985" not in lv: continue
        if level_filter == "211" and "211" not in lv: continue
        if level_filter == "\u53cc\u4e00\u6d41" and "\u53cc\u4e00\u6d41" not in lv: continue
        if level_filter == "\u672c\u79d1" and "\u672c\u79d1" not in lv: continue
        if level_filter == "\u6c11\u529e" and "\u6c11\u529e" not in school.get("nature","") and "\u6c11\u529e" not in lv: continue
        if level_filter == "\u4e13\u79d1" and "\u4e13\u79d1" not in lv and "\u9ad8\u804c" not in lv: continue
        if province_filter != "\u5168\u90e8":
            sp = school.get("province","") or school.get("province_name","")
            if province_filter not in sp and school.get("city","") != province_filter: continue
        filtered[name] = school

    if filtered:
        st.markdown(f'<div style="text-align:right;color:#888;margin-bottom:8px;font-size:13px">\u5171\u67e5\u627e\u5230 <strong>{len(filtered)}</strong> \u6240\u5b66\u6821\uff08\u663e\u793a\u524d 200 \u6240\uff09</div>', unsafe_allow_html=True)
        data = []
        for name, school in list(filtered.items())[:200]:
            ranking = get_ranking_ext(name)
            living = get_school_living(name)
            data.append({"\u5b66\u6821": name, "\u5c42\u6b21": school.get("level",""), "\u57ce\u5e02": school.get("city",""), "\u5206\u6570": format_score_str(school.get("scores",{})), "\u6392\u540d": ranking.get("\u8f6f\u79d1\u6392\u540d","") if ranking else "", "\u5bbf\u820d": (living.get("\u5bbf\u820d\u6761\u4ef6","") or "")[:12] if living else ""})
        st.dataframe(pd.DataFrame(data), use_container_width=True, hide_index=True)
    else:
        st.info("\u672a\u627e\u5230\u5339\u914d\u7684\u5b66\u6821\uff0c\u8bf7\u8c03\u6574\u7b5b\u9009\u6761\u4ef6")

# ========== PAGE: \u4e13\u4e1a\u67e5\u8be2 ==========
elif page_key == "\u4e13\u4e1a\u67e5\u8be2":
    st.markdown("<h1>\U0001f4da \u4e13\u4e1a\u67e5\u8be2</h1>", unsafe_allow_html=True)
    st.markdown('<div class="card">', unsafe_allow_html=True)
    col1, col2 = st.columns([2,1])
    with col1: major_search = st.text_input("\U0001f50d \u641c\u7d22\u4e13\u4e1a", placeholder="\u8f93\u5165\u4e13\u4e1a\u540d\u79f0")
    with col2: selected_major = st.selectbox("\U0001f4c4 \u6216\u9009\u62e9\u4e13\u4e1a", ["\u8bf7\u9009\u62e9"] + ALL_MAJOR_NAMES)
    st.markdown("</div>", unsafe_allow_html=True)

    major_name = selected_major if selected_major != "\u8bf7\u9009\u62e9" else ""
    if major_search:
        matches = [m for m in ALL_MAJOR_NAMES if major_search.lower() in m.lower()]
        if matches:
            major_name = st.radio("\u5339\u914d\u7ed3\u679c\uff1a", matches, horizontal=True) if len(matches) > 1 else matches[0]

    if major_name:
        info = get_major_info_by_name(major_name)
        if info:
            st.markdown(f'<h2 style="margin-top:0">{major_name}</h2>', unsafe_allow_html=True)
            ca, cb = st.columns(2)
            with ca:
                st.markdown('<div class="card"><div class="card-title">\U0001f4c8 \u57fa\u672c\u4fe1\u606f</div>', unsafe_allow_html=True)
                st.markdown(f'<div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #f0f0f0"><span style="color:#888">\u5c31\u4e1a\u7387</span><strong>{info.get("employment_rate","?")}%</strong></div>', unsafe_allow_html=True)
                st.markdown(f'<div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #f0f0f0"><span style="color:#888">\u85aa\u8d44\u4e2d\u4f4d\u6570</span><strong>{info.get("salary_median","?")}\u5143/\u6708</strong></div>', unsafe_allow_html=True)
                if info.get("jobs"): st.markdown(f'<div style="padding:6px 0"><span style="color:#888">\u5c31\u4e1a\u65b9\u5411</span><br>{make_tags(info["jobs"].split(","))}</div>', unsafe_allow_html=True)
                st.markdown('</div>', unsafe_allow_html=True)
            with cb:
                deep = get_major_deep_analysis_ext(major_name)
                if deep:
                    st.markdown('<div class="card"><div class="card-title">\U0001f4c9 \u85aa\u8d44\u6210\u957f\u66f2\u7ebf</div>', unsafe_allow_html=True)
                    salaries = deep.get("\u85aa\u8d44\u6210\u957f",{})
                    if salaries:
                        chart_data = pd.DataFrame({"\u9636\u6bb5": list(salaries.keys()), "\u6708\u85aa(\u5143)": list(salaries.values())})
                        st.bar_chart(chart_data.set_index("\u9636\u6bb5"), height=150)
                    st.markdown(f'<div style="margin-top:8px"><span style="color:#888;font-size:13px">\u664b\u5347\u8def\u5f84</span><br>{deep.get("\u664b\u5347\u8def\u5f84","")}</div>', unsafe_allow_html=True)
                    st.markdown(f'<div style="margin-top:4px"><span style="color:#888;font-size:13px">\u5de5\u4f5c\u5f3a\u5ea6</span> {deep.get("\u5de5\u4f5c\u5f3a\u5ea6","")} \u2003<span style="color:#888;font-size:13px">35\u5c81\u5371\u673a</span> {deep.get("35\u5c81\u5371\u673a","")}</div>', unsafe_allow_html=True)
                    st.markdown('</div>', unsafe_allow_html=True)

            emp = get_major_employment_deep_ext(major_name)
            if emp:
                st.markdown('<div class="card"><div class="card-title">\U0001f3e2 \u5206\u5c42\u5c31\u4e1a\u6570\u636e</div>', unsafe_allow_html=True)
                emp_data = pd.DataFrame({
                    "\u5c42\u6b21": ["985","211","\u53cc\u975e"],
                    "\u5c31\u4e1a\u7387": [f"{emp.get('\u5c31\u4e1a\u7387_985',0)*100:.0f}%", f"{emp.get('\u5c31\u4e1a\u7387_211',0)*100:.0f}%", f"{emp.get('\u5c31\u4e1a\u7387_\u53cc\u975e',0)*100:.0f}%"],
                    "\u5e73\u5747\u85aa\u8d44": [f"{emp.get('\u85aa\u8d44_985',0)}\u5143", f"{emp.get('\u85aa\u8d44_211',0)}\u5143", f"{emp.get('\u85aa\u8d44_\u53cc\u975e',0)}\u5143"],
                })
                st.dataframe(emp_data, hide_index=True, use_container_width=True)
                if emp.get("\u5934\u90e8\u516c\u53f8"):
                    st.markdown(f'<div style="margin-top:8px"><span style="color:#888">\u5934\u90e8\u516c\u53f8</span>: {make_tags(emp["\u5934\u90e8\u516c\u53f8"])}</div>', unsafe_allow_html=True)
                st.markdown('</div>', unsafe_allow_html=True)

            city_m = get_major_city_match_ext(major_name)
            if city_m:
                st.markdown('<div class="card"><div class="card-title">\U0001f30d \u6700\u4f73\u5c31\u4e1a\u57ce\u5e02</div>', unsafe_allow_html=True)
                all_cities = []
                for tier, cities in city_m.items():
                    for c in cities:
                        c["tier"] = tier
                        all_cities.append(c)
                city_df = pd.DataFrame(all_cities)
                if not city_df.empty:
                    st.dataframe(city_df[["city","tier","avg_salary","reason"]].rename(columns={"city":"\u57ce\u5e02","tier":"\u68af\u961f","avg_salary":"\u5e73\u5747\u85aa\u8d44","reason":"\u539f\u56e0"}), hide_index=True, use_container_width=True)
                st.markdown('</div>', unsafe_allow_html=True)

            card = get_major_score_card_ext(major_name)
            if card:
                st.markdown('<div class="card"><div class="card-title">\u2b50 \u7efc\u5408\u8bc4\u5206</div>', unsafe_allow_html=True)
                cols = st.columns(7)
                dims = ["\u5c31\u4e1a\u7387","\u85aa\u8d44\u6c34\u5e73","\u5de5\u4f5c\u5f3a\u5ea6","35\u5c81\u5371\u673a","\u884c\u4e1a\u524d\u666f","\u8f6c\u884c\u96be\u5ea6","\u8003\u7814\u6536\u76ca"]
                for i, d in enumerate(dims):
                    v = card.get(d, 0)
                    with cols[i]:
                        st.markdown(f'<div style="text-align:center;padding:8px;background:#f8f9fc;border-radius:8px"><div style="font-size:20px;font-weight:700;color:{score_to_color(v)}">{v}</div><div style="font-size:11px;color:#888;margin-top:2px">{d}</div></div>', unsafe_allow_html=True)
                st.markdown(f'<div style="text-align:center;margin-top:12px;font-size:18px"><strong>\u603b\u5206\uff1a{card.get("\u603b\u5206","?")}/100</strong> \u2003<span class="gold-badge">{card.get("\u7b49\u7ea7","?")}</span></div>', unsafe_allow_html=True)
                st.markdown('</div>', unsafe_allow_html=True)

            path = get_career_path(major_name)
            if path:
                st.markdown('<div class="card"><div class="card-title">\U0001f6e4\ufe0f 20\u5e74\u804c\u4e1a\u8def\u5f84\u6a21\u62df</div>', unsafe_allow_html=True)
                for stage, detail in path.get("\u5178\u578b\u8def\u5f84",{}).items():
                    st.markdown(f'<div style="background:#f8f9fc;padding:10px 14px;border-radius:10px;margin-bottom:6px;border-left:3px solid #e8b840"><strong>{stage}</strong> {detail.get("\u804c\u4f4d","")} | \u5e74\u85aa{detail.get("\u5e74\u85aa","")}<br><span style="color:#888;font-size:13px">{detail.get("\u72b6\u6001","")}</span></div>', unsafe_allow_html=True)
                st.markdown('</div>', unsafe_allow_html=True)

            match = get_school_major_match_ext(major_name)
            if match:
                st.markdown('<div class="card"><div class="card-title">\U0001f3c6 \u63a8\u8350\u9662\u6821</div>', unsafe_allow_html=True)
                for tier, schools in match.items():
                    if tier in ("\u7b2c\u4e00\u68af\u961f","\u7b2c\u4e8c\u68af\u961f","\u7b2c\u4e09\u68af\u961f"):
                        st.markdown(f'<div style="margin-bottom:6px"><span style="color:#888;font-size:13px">{tier}</span> {make_tags(schools)}</div>', unsafe_allow_html=True)
                st.markdown('</div>', unsafe_allow_html=True)
        else:
            st.warning(f"\u6682\u672a\u6536\u5f55\u300c{major_name}\u300d\u7684\u8be6\u7ec6\u4fe1\u606f")
    else:
        st.info("\u8bf7\u641c\u7d22\u6216\u9009\u62e9\u4e00\u4e2a\u4e13\u4e1a\u67e5\u770b\u8be6\u60c5")

# ========== PAGE: \u6570\u636e\u770b\u677f ==========
elif page_key == "\u6570\u636e\u770b\u677f":
    st.markdown("<h1>\U0001f4ca \u6570\u636e\u770b\u677f</h1>", unsafe_allow_html=True)
    st.markdown("<p style='color:#888;font-size:15px'>\u77e5\u8bc6\u5e93\u6570\u636e\u7edf\u8ba1\u4e0e\u53ef\u89c6\u5316</p>", unsafe_allow_html=True)

    cols = st.columns(4)
    with cols[0]: st.metric("\U0001f3eb \u9662\u6821\u603b\u6570", f"{len(ALL_SCHOOLS)}+", delta="1500+")
    with cols[1]: st.metric("\U0001f4da \u4e13\u4e1a\u603b\u6570", f"{len(ALL_MAJOR_NAMES)}+", delta="111+")
    with cols[2]: st.metric("\U0001f3d8\ufe0f \u57ce\u5e02\u6570\u636e", "50+", delta="31\u7701")
    with cols[3]: st.metric("\U0001f4c8 \u884c\u4e1a\u5206\u6790", "40+", delta="\u5168\u9762\u8986\u76d6")

    c1, c2 = st.columns(2)
    with c1:
        st.markdown('<div class="card"><div class="card-title">\U0001f3eb \u9662\u6821\u5c42\u6b21\u5206\u5e03</div>', unsafe_allow_html=True)
        level_counts = {}
        for school in ALL_SCHOOLS.values():
            lv = school.get("level","\u672a\u77e5")
            level_counts[lv] = level_counts.get(lv, 0) + 1
        if level_counts:
            st.bar_chart(pd.DataFrame({"\u5c42\u6b21": list(level_counts.keys()), "\u6570\u91cf": list(level_counts.values())}).set_index("\u5c42\u6b21"), height=250)
        st.markdown("</div>", unsafe_allow_html=True)
    with c2:
        st.markdown('<div class="card"><div class="card-title">\U0001f4da \u4e13\u4e1a\u63a8\u8350\u5206\u7c7b</div>', unsafe_allow_html=True)
        class_data = []
        for tier, majors in ZHANG_XUEFENG_MAJOR_CATEGORIES.items():
            class_data.append({"\u5206\u7c7b": tier, "\u6570\u91cf": len(majors)})
        if class_data:
            st.bar_chart(pd.DataFrame(class_data).set_index("\u5206\u7c7b"), height=250, color="#e8b840")
        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown('<div class="card"><div class="card-title">\U0001f4b0 \u5956\u5b66\u91d1\u4f53\u7cfb</div>', unsafe_allow_html=True)
    sch_data = [{"\u7c7b\u578b": name, "\u91d1\u989d": info.get("\u91d1\u989d",""), "\u6bd4\u4f8b": info.get("\u6bd4\u4f8b","")} for name, info in SCHOLARSHIP_TYPES.items()]
    if sch_data:
        st.dataframe(pd.DataFrame(sch_data), hide_index=True, use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)

    st.markdown('<div class="card"><div class="card-title">\U0001f3e0 \u5bb6\u5ead\u8d22\u52a1\u89c4\u5212\u5efa\u8bae</div>', unsafe_allow_html=True)
    for tier, plan in FINANCIAL_PLANNING.items():
        with st.expander(tier):
            st.markdown(f'<div style="margin-bottom:4px"><span style="color:#888">\u7b56\u7565</span> {plan.get("\u7b56\u7565","")}</div>', unsafe_allow_html=True)
            st.markdown(f'<div style="margin-bottom:4px"><span style="color:#888">\u6708\u9884\u7b97</span> {plan.get("\u6708\u9884\u7b97","")}</div>', unsafe_allow_html=True)
            st.markdown(f'<div style="margin-bottom:4px"><span style="color:#888">\u63a8\u8350\u8def\u5f84</span> {", ".join(plan.get("\u63a8\u8350\u8def\u5f84",[]))}</div>', unsafe_allow_html=True)
            if plan.get("\u907f\u5751"): st.warning(f"\u907f\u5751\uff1a{plan.get('\u907f\u5751','')}")
    st.markdown("</div>", unsafe_allow_html=True)

st.markdown('<div class="footer">\U0001f393 \u9ad8\u8003\u5fd7\u613f\u7b56\u7565\u5e08 - \u57fa\u4e8e\u5f20\u96ea\u5cf0\u77e5\u8bc6\u6846\u67b6 | \u6570\u636e\u6765\u6e90\uff1a\u638c\u4e0a\u9ad8\u8003</div>', unsafe_allow_html=True)
'''

import re
def fix_fstring_backslashes(text):
    def replace_unicode(m):
        return chr(int(m.group(1), 16))
    return re.sub(r'\\u([0-9a-fA-F]{4})', replace_unicode, text)
content = fix_fstring_backslashes(content)
with open('app.py', 'w', encoding='utf-8') as f:
    f.write(content)
print("app.py written, length:", len(content))
